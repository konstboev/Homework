function split (source) {
    const newSource = [];
    
    for (const item of source) {
      newSource.push(item);
    }
    
    return newSource;
}
  
  function join (source) {
    let newSource = '';
    
    for (const item of source) {
       newSource += item;
    }
    
    return newSource;
}
  
  
let utils = {
    reverse:  source => {
      const isString = typeof source === 'string';
      const newSource = [];
    
      source = isString ? split(source): source;
    
      for (let index = source.length - 1; index >= 0; index--) {
            newSource.push(source[index]);
      }
    
      return isString ? join(newSource): newSource;
    },
    
    sort: source => {
      const isString = typeof source === 'string';
    
      source = isString ? split(source): source;
    
      for (let index = 0; index < source.length - 1; index++) {
        for (let index2 = 0; index2 < source.length - index - 1; index2++) {
          if (source[index2] > source[index2+1]) {
            let tmp = source[index2 + 1];
            let tmp2 = source[index2];
          
            source[index2 + 1] = tmp2;
            source[index2] = tmp;
          }
        }  
      }
    
      return isString ? join(source): source;
    },
    
    verifyNumbers: source => {
      const result = [];
    
      for (const item of source) {
        let possibleNum = +item;
  
        if (possibleNum === possibleNum) {
          result.push(item);
        }
      }
    
      return result;
    },
    
    getMin: source => {
      let minValue = source[0];
    
      for (const item of source) {
        if (item < minValue) {
          minValue = item;
        }
      }
    
      return minValue;
    }
};


console.log(utils.reverse('hello'))
console.log(utils.sort('hello'))
console.log(utils.verifyNumbers('abcde123'))
console.log(utils.getMin([-1,0,1,2,3]));