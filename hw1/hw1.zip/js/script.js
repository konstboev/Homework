alert ('Hello!');

let user = prompt('What is your name?');

alert('Nice to meet you, '+user);

let age = prompt('How old are you?');

alert(`You ${age} years old!`);